packageFiles = c()
urlFile  = 'https://cran.r-project.org/bin/macosx/mavericks/contrib/3.3/slam_0.1-37.tgz'
destFile = 'slam_0.1-37.tgz'
download.file(urlFile,
              destfile = destFile)
urlFile  = 'https://cran.r-project.org/bin/macosx/mavericks/contrib/3.3/tm_0.6-2.tgz'
destFile = 'tm_0.6-2.tgz'
download.file(urlFile,
              destfile = destFile)
urlFile  = 'https://cran.r-project.org/bin/macosx/mavericks/contrib/3.3/RWeka_0.4-26.tgz'
destFile = 'RWeka_0.4-26.tgz'
download.file(urlFile,
              destfile = destFile)
urlFile  = 'https://cran.r-project.org/bin/macosx/mavericks/contrib/3.3/SnowballC_0.5.1.tgz'
destFile = 'SnowballC_0.5.1.tgz'
download.file(urlFile,
              destfile = destFile)



install.packages('slam_0.1-37.tgz', repos = NULL, type="source")
install.packages('RWeka_0.4-26.tgz', repos = NULL, type="source")
install.packages('SnowballC_0.5.1.tgz', repos = NULL, type="source")


install.packages('rJava')
install.packages('RWekajars')
install.packages('NLP')

install.packages('tm_0.6-2.tgz', repos = NULL, type="source")
