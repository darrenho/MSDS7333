The main two R files are 

-textProcessingSupervised.R
-textProcessingUnsupervised

Make sure you install any packages that are used.  The other two R files

- textProcessingInstall.R
- textProcessingDocTerm.R

These are use to create the document term matrices for these problems.  They require some care in installing the appropriate packages, so I created the document term matrices if you’d like to skip that part.  On my OS/computer, running the Install file and then the DocTerm file works, but it could be OS/computer dependent (it requires working and appropriate versions of a fortran compiler, c compiler, and java.



We will go through these examples in class tomorrow.