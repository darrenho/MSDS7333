#docConcept = matrix(scan('./data/tmntDocConcept.csv',sep=','),nrow=8,byrow=TRUE)
#docTerm    = matrix(scan('./data/tmntDocTermDense.csv',sep=','),nrow=8,byrow=TRUE)

Yqual      = scan('./data/tmntLabelsSplit.csv',sep=',',what='')
docTerm    = matrix(scan('./data/tmntDocTermDenseSplit.csv',sep=','),nrow=length(Yqual),byrow=TRUE)
terms      = scan('./data/tmntTermsSplit.csv',sep=',',what='')


require(wordcloud)
require(glmnet)

Y = rep(0,length(Yqual))
Y[Yqual == 'artist'] = 1


out.glmnet    = glmnet(y=Y,x=docTerm,family='binomial')#The lasso fit
out.cv.glmnet = cv.glmnet(y=Y,x=docTerm,family='binomial')#The CV score for lasso fits
beta.glmnet   = drop(coef(out.cv.glmnet,s='lambda.min'))[-1]#drop gets rid of unnecessary dimension
Yhat.glmnet   = drop(predict(out.cv.glmnet,docTerm,s='lambda.min',type='class'))

table(Yhat.glmnet,Y)
#These next two lines get nonzero coefficients (model selection)
terms.glmnet        = terms[abs(beta.glmnet)>0]
beta.glmnet.nonzero = beta.glmnet[abs(beta.glmnet)>0]

negPos = beta.glmnet.nonzero > 0
colors = rep('red',length(beta.glmnet.nonzero))
colors[negPos] = 'blue'


wordcloud(terms.glmnet,abs(beta.glmnet.nonzero), scale=c(4,.5),
          colors = colors,ordered.colors=T,
          max.words=100, random.order=T, rot.per=.15)




###
# Use the doc concept matrix
####
docConcept = matrix(scan('./data/tmntDocConceptDenseSplit.csv',sep=','),nrow=length(Yqual),byrow=TRUE)

out.glmnet    = glmnet(y=Y,x=docConcept,family='binomial')#The lasso fit
out.cv.glmnet = cv.glmnet(y=Y,x=docConcept,family='binomial')#The CV score for lasso fits
beta.glmnet   = drop(coef(out.cv.glmnet,s='lambda.min'))[-1]#drop gets rid of unnecessary dimension
Yhat.glmnet   = drop(predict(out.cv.glmnet,docConcept,s='lambda.min',type='class'))

table(Yhat.glmnet,Y)

require(scatterplot3d)
activeConcepts = (1:5)[abs(beta.glmnet)>0]
scatterplot3d(docConcept[,sample(activeConcepts)],color = Y+2,pch=16,cex.symbols =.6,
              xlab=as.character(activeConcepts[1]),
              ylab=as.character(activeConcepts[2]),
              zlab=as.character(activeConcepts[3]))
#Can we do a different classification approach?
