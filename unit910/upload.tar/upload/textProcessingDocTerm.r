Sys.setenv(NOAWT=TRUE)
require(SnowballC)
require(RWeka)
require(rJava)
require(tm)

data(crude)
corp = VCorpus(VectorSource(crude))
dtm = DocumentTermMatrix(corp,
                         control=list(tolower=TRUE,
                                      removePunctuation=list(preserve_intra_word_dashes=TRUE),
                                      removeNumbers=TRUE,
                                      stemming=TRUE,
                                      stopwords = TRUE,
                                      weighting=weightTfIdf,
                                      wordLengths = c(2,15))
)

#docTermDense = as.matrix(dtm) #creates a dense matrix
require(Matrix)
docNames      = dtm$dimnames$Docs
terms         = dtm$dimnames$Terms
docTermSparse = with(dtm,sparseMatrix(i = i, j = j, x = v,dims=c(nrow,ncol)))



docTermDense = as.matrix(docTermSparse)
write.table(docTermDense,'./data/reutersDocTermDense.csv',col.names=FALSE,row.names=FALSE,sep=',')
writeMM(docTermSparse,file='./data/reutersDocTerm.spar')
write.table(terms,'./data/reutersTerms.csv',col.names=FALSE,row.names=FALSE,sep=',')

print(object.size(docTermSparse),units='auto')
print(object.size(dtm),units='auto')

#############
# TMNT 
#############

load(file="./data/docs.Rdata")
docs$query = NULL
corp = VCorpus(VectorSource(docs))
dtm = DocumentTermMatrix(corp,
                         control=list(tolower=TRUE,
                                      removePunctuation=list(preserve_intra_word_dashes=TRUE),
                                      removeNumbers=TRUE,
                                      stemming=TRUE,
                                      stopwords = TRUE,
                                      weighting=weightTfIdf,
                                      wordLengths = c(3,10))
)
require(Matrix)
docNames      = dtm$dimnames$Docs
terms         = dtm$dimnames$Terms
docTermSparse = with(dtm,sparseMatrix(i = i, j = j, x = v,dims=c(nrow,ncol)))



print(object.size(docTermSparse),units='auto')
print(object.size(dtm),units='auto')

require(irlba)
lsi_sparse = irlba(docTermSparse,
                   nv = 5,nu = 5,
                   tol=1e-10)
print(object.size(lsi_sparse),units='auto')

labels = c("(tmnt leo)","(tmnt rap)","(tmnt mic)","(tmnt don)",
           "(real leo)","(real rap)","(real mic)","(real don)")

lsi_conceptTerm = lsi_sparse$v
row.names(lsi_conceptTerm) = terms
lsi_docConcept  = lsi_sparse$u
row.names(lsi_docConcept) = labels

sort(lsi_docConcept[,1],decreasing=TRUE)

require(ggplot2)
require(dplyr)

plotObj = data.frame('Index_1'=lsi_docConcept[,1],
                     'Index_2'=lsi_docConcept[,2],
                     'labels' = labels,
                     'color'  = c(rep('red',4),rep('blue',4)))

plotObj %>% filter(abs(Index_1)>.1|abs(Index_2)>.1) %>%
  ggplot(mapping=aes(label=labels,
                     x = Index_1,
                     y = Index_2,
                     size=2,
                     col=color))+
  geom_text()+scale_size(range=3)+theme(legend.position="none")


## Write output
write.table(lsi_docConcept,'./data/tmntDocConcept.csv',col.names=FALSE,row.names=FALSE,sep=',')
docTermDense = as.matrix(docTermSparse)
write.table(docTermDense,'./data/tmntDocTermDense.csv',col.names=FALSE,row.names=FALSE,sep=',')
writeMM(docTermSparse,file='./data/tmntDocTerm.spar')
write.table(terms,'./data/tmntTerms.csv',col.names=FALSE,row.names=FALSE,sep=',')

###
# Split up the documents into chunks
###
nCharInDoc  = 2500
splitDocs   = c()
splitLabels = c()
splitLabelsIter = 0
for(doc in docs){
  splitLabelsIter = splitLabelsIter + 1
  notAtEnd = T
  iterSplit = 0
  while(notAtEnd){
    if(splitLabelsIter <= 4){
      newChunkLabel = 'tmnt'
    }else{
      newChunkLabel = 'artist'
    }
    splitLabels = c(splitLabels,newChunkLabel)
    iterSplit = iterSplit + 1
    newChunk = substr(doc,(iterSplit - 1)*nCharInDoc+1,
                      iterSplit*nCharInDoc)
    splitDocs = c(splitDocs,newChunk)
    if(nchar(newChunk) < nCharInDoc){
      notAtEnd = F }
  } 
}

corp = VCorpus(VectorSource(splitDocs))
dtm = DocumentTermMatrix(corp,
                         control=list(tolower=TRUE,
                                      removePunctuation=list(preserve_intra_word_dashes=TRUE),
                                      removeNumbers=TRUE,
                                      stemming=TRUE,
                                      stopwords = TRUE,
                                      weighting=weightTfIdf,
                                      wordLengths = c(3,10))
)
require(Matrix)
docNames      = dtm$dimnames$Docs
terms         = dtm$dimnames$Terms
docTermSparse = with(dtm,sparseMatrix(i = i, j = j, x = v,dims=c(nrow,ncol)))
docTermDense = as.matrix(docTermSparse)
lsi_sparse = irlba(docTermSparse,
                   nv = 5,nu = 5,
                   tol=1e-10)
lsi_docConcept  = lsi_sparse$u

write.table(docTermDense,'./data/tmntDocTermDenseSplit.csv',col.names=FALSE,row.names=FALSE,sep=',')
write.table(lsi_docConcept,'./data/tmntDocConceptDenseSplit.csv',col.names=FALSE,row.names=FALSE,sep=',')
write.table(splitLabels,'./data/tmntLabelsSplit.csv',col.names=FALSE,row.names=FALSE,sep=',')
write.table(terms,'./data/tmntTermsSplit.csv',col.names=FALSE,row.names=FALSE,sep=',')
