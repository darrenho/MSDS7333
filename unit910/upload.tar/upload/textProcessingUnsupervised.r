require(Matrix)

terms         = scan('./data/reutersTerms.csv',sep=',',what='')
docTerm       = matrix(scan('./data/reutersDocTermDense.csv',sep=','),ncol=length(terms),byrow=TRUE)
docTermSparse = readMM(file='./data/reutersDocTerm.spar')


lsi_dense = svd(docTermSparse)
print(object.size(lsi_dense),units='auto')
require(irlba)#This may produce a warning, but it is fine
lsi_sparse = irlba(docTermSparse,
                   nv = 10,nu = 10,
                   tol=1e-10)
print(object.size(lsi_sparse),units='auto')


lsi_conceptTerm = lsi_sparse$v
row.names(lsi_conceptTerm) = terms
lsi_docConcept  = lsi_sparse$u
row.names(lsi_docConcept) = as.character(1:20)

signif(sort(lsi_conceptTerm[,1],decreasing=TRUE)[1:24],2)
signif(sort(lsi_conceptTerm[,1],decreasing=FALSE)[1:24],2)

require(ggplot2)
require(dplyr)
plotObj = data.frame('Index_1'=lsi_conceptTerm[,1],
                     'Index_2'=lsi_conceptTerm[,2],
                     'labels'  = terms)

plotObj %>% filter(abs(Index_1)>.1|abs(Index_2)>.1) %>%
  ggplot(mapping=aes(label=labels,
                     x = Index_1,
                     y = Index_2,
                     alpha=.5,
                     angle=0,
                     size=2))+
      geom_text()+scale_size(range=2)+theme(legend.position="none")


#############
# TMNT 
#############
terms         = scan('./data/tmntTerms.csv',sep=',',what='')
docTerm       = matrix(scan('./data/tmntDocTermDense.csv',sep=','),ncol=length(terms),byrow=TRUE)
docTermSparse = readMM(file='./data/tmntDocTerm.spar')

require(irlba)
lsi_sparse = irlba(docTermSparse,
                   nv = 5,nu = 5,
                   tol=1e-10)
print(object.size(lsi_sparse),units='auto')

labels = c("(tmnt leo)","(tmnt rap)","(tmnt mic)","(tmnt don)",
           "(real leo)","(real rap)","(real mic)","(real don)")

lsi_conceptTerm = lsi_sparse$v
row.names(lsi_conceptTerm) = terms
lsi_docConcept  = lsi_sparse$u
row.names(lsi_docConcept) = labels

sort(lsi_docConcept[,1],decreasing=TRUE)

require(ggplot2)
require(dplyr)

plotObj = data.frame('Index_1'=lsi_docConcept[,1],
                     'Index_2'=lsi_docConcept[,2],
                     'labels' = labels,
                     'color'  = c(rep('red',4),rep('blue',4)))

plotObj %>% filter(abs(Index_1)>.1|abs(Index_2)>.1) %>%
  ggplot(mapping=aes(label=labels,
                     x = Index_1,
                     y = Index_2,
                     size=2,
                     col=color))+
      geom_text()+scale_size(range=3)+theme(legend.position="none")


